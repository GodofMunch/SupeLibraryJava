create trigger ENDOFRENTAL_TRG
  before insert or update
  on RESERVATION
  for each row
  DECLARE
    c_endOfrental RESERVATION.ENDOFRENTAL%TYPE;
    c_startOfRental RESERVATION.STARTOFRENTAL%TYPE;
    c_roomid RESERVATION.ROOMID%TYPE;
    e_errorRoomAlreadyBooked varchar2(255);
    e_errorBadDate varchar2(255);
BEGIN
    c_endOfRental := :NEW.ENDOFRENTAL;
    c_startOfRental := : NEW.STARTOFRENTAL;
    e_errorBadDate := 'It is impossible to return a room that has not been rented';
    
    IF(c_startofrental > c_endofrental)
    THEN
            RAISE_APPLICATION_ERROR(-20000, e_errorBadDate);
    END IF;
END;
/

