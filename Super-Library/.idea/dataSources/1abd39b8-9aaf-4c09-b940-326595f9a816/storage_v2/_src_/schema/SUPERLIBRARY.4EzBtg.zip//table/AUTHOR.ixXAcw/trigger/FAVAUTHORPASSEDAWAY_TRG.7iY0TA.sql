create trigger FAVAUTHORPASSEDAWAY_TRG
  after update of YEARFINISHED
  on AUTHOR
  for each row
  DECLARE 
  v_yearfinished AUTHOR.YEARFINISHED%TYPE;
  v_authorid AUTHOR.AUTHORID%TYPE;
  v_number1 VARCHAR2(255);
  v_number2 VARCHAR2(255);
  v_number3 VARCHAR2(255);
  TYPE arrayofnumbers IS TABLE OF NUMBER;
  id_customer arrayofnumbers;
  TYPE arrayofvarchar IS TABLE OF VARCHAR2(255);
  a_titles arrayofvarchar;
  
BEGIN
    
    IF(v_yearfinished != 'Present')
    THEN
      Select CUSTOMERID BULK COLLECT into id_customer
      From CUSTOMER C
      Where C.FAVAUTHOR = v_authorid;
      FOR i IN 1..id_customer.COUNT LOOP
        INSERT into NOTIFICATION(CUSTOMERID, NOTIFTEXT) Values(id_customer(i), 'We''re sad to announce that  : '+ :NEW.NAME + 'Passed away');
      END LOOP;
      --TOP 3 BOOKS OF the author1
      --SELECT TITLE BULK COLLECT into a_titles
      --FROM(SELECT TIMESRENTED, TITLE, RANK() OVER (ORDER BY TIMESRENTED DESC) AS RNK
      --      FROM  BOOK), BOOK B
      --      WHERE B.AUTHORID = v_authorid
      --      AND RNK <= 3;
    END IF;
END;
/

