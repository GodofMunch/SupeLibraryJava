create trigger DATEPAID_TRG
  before insert or update
  on CUSTOMERFEES
  for each row
  DECLARE 
    c_datePaid CUSTOMERFEES.DATEPAID%TYPE;
    c_dateIncurred CUSTOMERFEES.DATEINCURRED%TYPE;
    c_errorCantPayEarly varchar2(255);
BEGIN

    c_datePaid := :NEW.DATEPAID;
    c_dateIncurred := :NEW.DATEINCURRED;
    c_errorCantPayEarly := 'Cannot Pay a fee that has not yet been incurred';
    
    IF(c_datePaid < c_dateIncurred)
    THEN
        RAISE_APPLICATION_ERROR(-20000, c_errorCantPayEarly);
    END IF;
END;
/

