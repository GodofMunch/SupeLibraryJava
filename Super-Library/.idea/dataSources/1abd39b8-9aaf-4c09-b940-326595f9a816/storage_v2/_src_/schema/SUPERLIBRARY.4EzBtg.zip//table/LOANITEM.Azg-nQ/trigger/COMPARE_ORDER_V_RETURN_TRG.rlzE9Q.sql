create trigger COMPARE_ORDER_V_RETURN_TRG
  before insert or update
  on LOANITEM
  for each row
  DECLARE
    c_loanDate LOANITEM.LOANDATE%TYPE;
    c_returnDate LOANITEM.RETURNDATE%TYPE;
    e_pastDate varchar2(255);
BEGIN
    c_loanDate := :NEW.LOANDATE;
    c_returnDate := :NEW.RETURNDATE;
    e_pastDate := 'Can''t Return a book before it has been rented!';

    IF(c_loanDate > c_returnDate)
    THEN
        RAISE_APPLICATION_ERROR(-20000, e_pastDate);
    END IF;
END;
/

