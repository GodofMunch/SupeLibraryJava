create PROCEDURE BLOBIMPORT(DIR IN VARCHAR2,
                                        FILENAME IN VARCHAR2)
   
AS         

v_lob BLOB;
l_bfile bfile;
amt NUMBER;

 
BEGIN
l_bfile := bfilename( 'C:\Users\HP\Desktop\Books',  '.jpg' );
for amt IN 1..10
loop
   
    INSERT INTO BOOK (PICTURE)
    VALUES (l_bfile) --VALUES (empty_blob()) 
    returning photo INTO v_lob;

    amt := dbms_lob.getlength( l_bfile );
    dbms_lob.fileopen( l_bfile ,dbms_lob.file_readonly);
    dbms_lob.loadfromfile( v_lob, l_bfile ,amt);

    dbms_output.put_line('File length is: '||dbms_lob.getlength( l_bfile ));
    dbms_output.put_line('Loaded length is: '||dbms_lob.getlength(v_lob));
    dbms_lob.fileclose( l_bfile );
end loop;
END;
/

