create trigger UPDATETIMESRENTED
  after insert or update of ISBN
  on LOANITEM
  BEGIN
  UPDATE BOOK
  SET TIMESRENTED = TIMESRENTED + 1;
END;
/

